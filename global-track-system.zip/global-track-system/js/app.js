/* =========================================================
   GLOBAL TRACK SYS
   - Dark world map (Leaflet + CARTO dark tiles)
   - Simulated aircraft flying between hubs
   - Optional LIVE aircraft from OpenSky Network (public, no key)
   ========================================================= */

// ---------- Config ----------
const CITIES = {
  NYC: [40.71, -74.01],  LON: [51.5, -0.12],   PAR: [48.86, 2.35],
  MOS: [55.75, 37.62],   CAI: [30.04, 31.24],  DXB: [25.2, 55.27],
  DEL: [28.61, 77.21],   CMB: [6.93, 79.86],   SIN: [1.35, 103.82],
  HKG: [22.32, 114.17],  TYO: [35.68, 139.69], SYD: [-33.87, 151.21],
  LAX: [34.05, -118.24], SAO: [-23.55, -46.63], JNB: [-26.2, 28.04]
};

const ROUTES = [
  ['NYC', 'LON'], ['LON', 'DXB'], ['DXB', 'SIN'], ['SIN', 'TYO'],
  ['LAX', 'TYO'], ['SAO', 'JNB'], ['CAI', 'DEL'], ['CMB', 'DXB'],
  ['MOS', 'PAR'], ['SYD', 'SIN'], ['HKG', 'LAX'], ['NYC', 'SAO'],
  ['JNB', 'DXB'], ['DEL', 'SIN']
];

const CLOCK_ZONES = {
  LON: 'Europe/London', NYC: 'America/New_York', DEL: 'Asia/Kolkata',
  TYO: 'Asia/Tokyo', SYD: 'Australia/Sydney'
};

const CALLSIGNS = ['UAE', 'BAW', 'SIA', 'QFA', 'DLH', 'CPA', 'ETD', 'AIC', 'THY', 'QTR', 'KLM', 'AAL'];
const OPENSKY_URL = 'https://opensky-network.org/api/states/all';
const LIVE_INTERVAL_MS = 20000; // OpenSky anonymous limit නිසා 20s

// ---------- Helpers ----------
const rnd = n => Math.floor(Math.random() * n);
const $ = id => document.getElementById(id);
const fmt = n => Number(n).toLocaleString();

function fixLng(a, b) {
  // Dateline හරහා කෙටිම මාර්ගය තෝරන්න
  let lng = b[1];
  while (lng - a[1] > 180) lng -= 360;
  while (lng - a[1] < -180) lng += 360;
  return [b[0], lng];
}

function arcAt(a, b, t) {
  // Great-circle වගේ පෙනුමට curved path එකක්
  const dist = Math.hypot(b[0] - a[0], b[1] - a[1]);
  const bulge = Math.min(14, dist * 0.15);
  return [
    a[0] + (b[0] - a[0]) * t + Math.sin(Math.PI * t) * bulge,
    a[1] + (b[1] - a[1]) * t
  ];
}

function bearing(from, to) {
  // North = 0°, clockwise
  return Math.atan2(to[1] - from[1], to[0] - from[0]) * 180 / Math.PI;
}

// ---------- Map ----------
const map = L.map('map', {
  zoomControl: false, minZoom: 2, maxZoom: 6, worldCopyJump: true
}).setView([25, 20], 2);

L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
  subdomains: 'abcd', maxZoom: 6, attribution: '&copy; OpenStreetMap &copy; CARTO'
}).addTo(map);
L.control.zoom({ position: 'bottomright' }).addTo(map);

const routeLayer = L.layerGroup().addTo(map);
const planeLayer = L.layerGroup().addTo(map);
const liveLayer = L.layerGroup().addTo(map);

// Hub dots
for (const [code, pos] of Object.entries(CITIES)) {
  L.circleMarker(pos, {
    radius: 3, color: '#4fe3ff', fillColor: '#4fe3ff', fillOpacity: 1, weight: 0
  }).bindTooltip(code, { className: 'tip' }).addTo(map);
}

// Route arcs
ROUTES.forEach(([ca, cb]) => {
  const a = CITIES[ca];
  const b = fixLng(a, CITIES[cb]);
  const pts = [];
  for (let i = 0; i <= 60; i++) pts.push(arcAt(a, b, i / 60));
  L.polyline(pts, { color: '#1fb6d6', weight: 1, opacity: 0.35, dashArray: '2 4' }).addTo(routeLayer);
});

// ---------- Simulated aircraft ----------
const PLANE_SVG = `<svg viewBox="0 0 24 24"><path fill="currentColor" d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/></svg>`;

function planeIcon(hdg) {
  return L.divIcon({
    className: 'plane-icon',
    html: `<div class="pl" style="transform:rotate(${hdg}deg)">${PLANE_SVG}</div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });
}

function setRotation(marker, hdg) {
  const el = marker.getElement && marker.getElement();
  const inner = el && el.querySelector('.pl');
  if (inner) inner.style.transform = `rotate(${hdg}deg)`;
}

const flights = [];
ROUTES.forEach(([ca, cb], ri) => {
  for (let k = 0; k < 2; k++) {
    const a = CITIES[ca];
    const b = fixLng(a, CITIES[cb]);
    const p = {
      cs: CALLSIGNS[rnd(CALLSIGNS.length)] + (100 + rnd(900)),
      from: ca, to: cb, a, b,
      t: Math.random(),
      dur: 90 + rnd(120),              // එක trip එකකට තත්පර
      alt: 28000 + rnd(12000),         // ft
      spd: 780 + rnd(140),             // km/h
      pos: a, hdg: 0, source: 'sim'
    };
    p.marker = L.marker(a, { icon: planeIcon(0) }).addTo(planeLayer);
    p.marker.on('click', () => select(p));
    flights.push(p);
  }
});

// ---------- Live OpenSky ----------
let liveOn = false;
let liveList = [];
let liveTimer = null;
let feedState = 'SIM';

async function fetchLive() {
  try {
    const res = await fetch(OPENSKY_URL);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const json = await res.json();

    liveLayer.clearLayers();
    liveList = [];
    (json.states || []).slice(0, 1500).forEach(s => {
      if (s[5] == null || s[6] == null) return;
      const ac = {
        cs: (s[1] || '????????').trim(),
        from: s[2] || '—', to: '',
        lng: s[5], lat: s[6],
        pos: [s[6], s[5]],
        alt: s[7] != null ? Math.round(s[7] * 3.281) : 0,
        spd: s[9] != null ? Math.round(s[9] * 3.6) : 0,
        hdg: s[10] || 0,
        source: 'live'
      };
      const m = L.circleMarker(ac.pos, {
        radius: 3, color: '#ffd166', fillColor: '#ffd166', fillOpacity: 0.9, weight: 0
      }).addTo(liveLayer);
      m.on('click', () => select(ac));
      ac.marker = m;
      liveList.push(ac);
    });
    feedState = 'OPENSKY';
  } catch (e) {
    feedState = 'ERROR';
  }
  $('stFeed').textContent = feedState;
}

$('liveBtn').addEventListener('click', () => {
  liveOn = !liveOn;
  $('liveBtn').textContent = 'OPENSKY: ' + (liveOn ? 'ON' : 'OFF');
  selected = null;
  if (liveOn) {
    map.removeLayer(planeLayer);
    feedState = 'LOADING';
    $('stFeed').textContent = feedState;
    fetchLive();
    liveTimer = setInterval(fetchLive, LIVE_INTERVAL_MS);
  } else {
    clearInterval(liveTimer);
    liveLayer.clearLayers();
    liveList = [];
    map.addLayer(planeLayer);
    feedState = 'SIM';
    $('stFeed').textContent = feedState;
  }
});

// ---------- Selection & panels ----------
let selected = null;

function current() {
  return liveOn ? liveList : flights;
}

function info(o) {
  if (o.source === 'sim') {
    return {
      cs: o.cs,
      route: `${o.from} → ${o.to}`,
      alt: Math.round(o.alt),
      spd: o.spd,
      hdg: Math.round(o.hdg + 360) % 360,
      lat: o.pos[0], lng: o.pos[1],
      status: o.t < 0.15 ? 'CLIMB' : o.t > 0.85 ? 'DESCENT' : 'CRUISE'
    };
  }
  return {
    cs: o.cs,
    route: o.from,
    alt: o.alt,
    spd: o.spd,
    hdg: Math.round(o.hdg),
    lat: o.lat, lng: o.lng,
    status: o.alt < 3000 ? 'GROUND' : o.alt < 20000 ? 'CLIMB' : 'CRUISE'
  };
}

function select(o) {
  selected = o;
  renderTarget();
  renderRoster();
}

function renderTarget() {
  const box = $('target');
  if (!selected) {
    box.innerHTML = 'Map එකේ aircraft එකක් click කරන්න.';
    return;
  }
  const d = info(selected);
  box.innerHTML = `
    <div class="big">${d.cs}</div>
    <b>ROUTE</b> ${d.route}<br>
    <b>STATUS</b> ${d.status}<br>
    <b>ALTITUDE</b> ${fmt(d.alt)} ft<br>
    <b>SPEED</b> ${fmt(d.spd)} km/h<br>
    <b>HEADING</b> ${d.hdg}°<br>
    <b>LAT</b> ${d.lat.toFixed(3)}<br>
    <b>LON</b> ${d.lng.toFixed(3)}
  `;
}

function renderRoster() {
  const list = current();
  const rows = list.slice(0, 12).map((o, i) => {
    const d = info(o);
    const cls = d.status === 'CLIMB' ? 'st-climb' : d.status === 'DESCENT' ? 'st-desc' : 'st-cruise';
    const sel = selected === o ? ' class="sel"' : '';
    return `<tr data-i="${i}"${sel}>
      <td>${d.cs}</td><td>${fmt(d.alt)}</td><td>${fmt(d.spd)}</td>
      <td class="${cls}">${d.status}</td></tr>`;
  });
  $('roster').innerHTML = rows.join('');
  $('stActive').textContent = fmt(list.length);
}

$('roster').addEventListener('click', e => {
  const tr = e.target.closest('tr');
  if (!tr) return;
  const o = current()[Number(tr.dataset.i)];
  if (o) select(o);
});

function renderCards() {
  const list = current().slice(0, 8);
  $('cards').innerHTML = list.map(o => {
    const d = info(o);
    return `<div class="card">
      <b>${d.cs}</b><br>
      FROM/TO: ${d.route}<br>
      ALT ${fmt(d.alt)} ft · ${fmt(d.spd)} km/h<br>
      HDG ${d.hdg}° · ${d.status}
    </div>`;
  }).join('');
}

// ---------- Decorative panels ----------
function makeBars(id, n) {
  $(id).innerHTML = Array.from({ length: n }, () => '<i></i>').join('');
}
function animateBars(id) {
  const bars = $(id).children;
  for (const b of bars) b.style.height = (15 + Math.random() * 85).toFixed(0) + '%';
}

const GAUGES = [['CPU', 0], ['MEM', 0], ['LINK', 0], ['UPLINK', 0], ['GPS', 0], ['RADAR', 0]];
function makeGauges() {
  $('gauges').innerHTML = GAUGES.map(([label]) => `
    <div class="gauge">
      <div class="ring" id="g-${label}"><span class="ring-val" id="v-${label}">0</span></div>
      <small>${label}</small>
    </div>`).join('');
}
function animateGauges() {
  GAUGES.forEach(([label]) => {
    const p = 40 + rnd(60);
    $('g-' + label).style.setProperty('--p', p);
    $('v-' + label).textContent = p + '%';
  });
}

// Signal wave canvas
const wave = $('wave');
const wctx = wave.getContext('2d');
function resizeWave() {
  const r = wave.getBoundingClientRect();
  wave.width = r.width * devicePixelRatio;
  wave.height = r.height * devicePixelRatio;
  wctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}
function drawWave(t) {
  const w = wave.clientWidth, h = wave.clientHeight;
  wctx.clearRect(0, 0, w, h);
  const colors = ['#37e6ff', '#1fb6d6', '#ffd166'];
  colors.forEach((c, k) => {
    wctx.beginPath();
    wctx.strokeStyle = c;
    wctx.lineWidth = 1.2;
    for (let x = 0; x <= w; x += 2) {
      const y = h / 2 + Math.sin(x * 0.04 + t * 0.003 * (k + 1)) * (h * 0.3) * Math.sin(x * 0.01 + k);
      x === 0 ? wctx.moveTo(x, y) : wctx.lineTo(x, y);
    }
    wctx.stroke();
  });
}

// Clocks
const clocksEl = $('clocks');
function updateClocks() {
  const now = new Date();
  clocksEl.innerHTML = Object.entries(CLOCK_ZONES).map(([code, tz]) => {
    const time = now.toLocaleTimeString('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    return `${code} <b>${time}</b>`;
  }).join('&nbsp;&nbsp;');
}

// ---------- Animation loop ----------
let last = performance.now();
let waveT = 0;

function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000);
  last = now;
  waveT += dt * 1000;

  if (!liveOn) {
    for (const p of flights) {
      p.t += dt / p.dur;
      if (p.t >= 1) p.t = 0;
      p.pos = arcAt(p.a, p.b, p.t);
      const ahead = arcAt(p.a, p.b, Math.min(1, p.t + 0.01));
      p.hdg = bearing(p.pos, ahead);
      p.marker.setLatLng(p.pos);
      setRotation(p.marker, p.hdg);
    }
  }

  drawWave(waveT);
  requestAnimationFrame(frame);
}

// ---------- Init ----------
makeBars('traffic', 40);
makeBars('sband', 24);
makeGauges();
resizeWave();
window.addEventListener('resize', resizeWave);

updateClocks();
animateBars('traffic');
animateBars('sband');
animateGauges();
renderRoster();
renderCards();

setInterval(updateClocks, 1000);
setInterval(() => { renderRoster(); if (selected) renderTarget(); }, 1000);
setInterval(renderCards, 3000);
setInterval(() => { animateBars('traffic'); animateBars('sband'); }, 700);
setInterval(animateGauges, 2000);

requestAnimationFrame(frame);
