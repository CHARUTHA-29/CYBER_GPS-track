GLOBAL TRACK SYS - Dashboard
============================

Files
-----
index.html      Main page
css/style.css   Styling (dark theme)
js/app.js       Map, aircraft simulation, OpenSky live feed

Features
--------
- Dark world map with hub cities and route arcs
- Aircraft flying between hubs (simulated)
- OPENSKY button: real live aircraft positions (public, no API key)
- Radar roster (click a row to select)
- Target data panel for the selected aircraft
- Live UTC/local clocks, traffic bars, gauges, signal wave

Run locally
-----------
Just double-click index.html (internet connection needed for the map).
Note: OpenSky live mode works best when hosted on https (not file://).

Hosting (free options)
----------------------
Option 1 - Netlify Drop (easiest)
  1. Go to https://app.netlify.com/drop
  2. Drag the "global-track-system" FOLDER (not the zip) into the page.
  3. You get a live link instantly.

Option 2 - GitHub Pages
  1. Create a new public repo on GitHub.
  2. Upload the files (index.html, css/, js/).
  3. Settings > Pages > Source: main branch > Save.
  4. Your site: https://<username>.github.io/<repo-name>/

Option 3 - Shared hosting (cPanel / public_html)
  1. Unzip the file.
  2. Upload index.html, css/ and js/ into public_html/ (keep folder structure).
  3. Open your domain.

Important
---------
- Keep the folder structure: css/style.css and js/app.js must stay in place.
- Map tiles: CARTO / OpenStreetMap (free, attribution shown on map).
- OpenSky anonymous API has rate limits. The app refreshes every 20 seconds.
  If it shows ERROR, wait a minute and toggle the button again.
- Simulated aircraft are for visuals only; they are not real flights.
